<template>
    <div>
        <!-- The Layout -->
        <router-view></router-view>
        <!-- This will now load Home.vue, Login.vue, Register.vue -->
    </div>
</template>

<script>
export default {
    name: "App",
};
</script>
